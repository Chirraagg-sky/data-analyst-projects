# 🔁 Customer Retention Analysis – Python + SQL

Analyzed customer churn using demographic and transaction data.

## Tools Used:
- Python (pandas, matplotlib)
- MySQL

## Key Features:
- Churn Rate Calculation
- Retention Trend Line
- Segment-Wise Churn Breakdown

## Insights:
- Corporate segment has highest churn
- High-value customers have better retention
