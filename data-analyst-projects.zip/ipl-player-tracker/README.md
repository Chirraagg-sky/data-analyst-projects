# 🏏 IPL Player Performance Tracker

Dashboard to track player stats across IPL seasons.

## Tools Used:
- Python (web scraping, pandas)
- Power BI

## Key Features:
- Top Scorer, Wicket Taker (KPIs)
- Runs by Top 10 Players
- Year-wise Performance Chart
- Slicers for Season, Team, Role
