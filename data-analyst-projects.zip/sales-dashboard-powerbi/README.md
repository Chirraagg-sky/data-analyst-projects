# 📊 Sales Performance Dashboard – Power BI

A dynamic dashboard created using Power BI to analyze regional and product category performance, customer trends, and key sales KPIs.

## Tools Used:
- Power BI (DAX, Slicers, KPIs)
- Excel

## Key Features:
- KPI cards: Total Sales, Profit, Quantity
- Sales by Region
- Monthly Sales Trend
- Sales by Category
- Slicers for Year, Region, Segment

## Insights:
- West region had highest sales in Q2
- Office Supplies generated low profit
